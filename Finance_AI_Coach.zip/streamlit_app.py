# streamlit_app.py
from core.utils.agent_response import AgentResponse
import streamlit as st
import pandas as pd
import io
import matplotlib.pyplot as plt
from agents.debt_analyzer import analyze_debt
from agents.fire_planner import generate_fire_message
from agents.budget_agent import generate_budget_advice
from agents.savings_agent import generate_savings_strategy
from core.utils.finance_math import monte_carlo_fire_probability
from agents_wrapper.budget_agent_wrapper import budget_agent_wrapper
from agents_wrapper.savings_agent_wrapper import savings_agent_wrapper
from agents_wrapper.debt_agent_wrapper import debt_agent_wrapper
from agents_wrapper.fire_planner_agent_wrapper import fire_agent_wrapper
#--------------------------------------------------
# Report Builder
# --------------------------------------------------
report_sections = []

report_sections.append(f"# AI Financial Coach Report\n")
report_sections.append(f"## User Snapshot")
st.set_page_config(
    page_title="AI Financial Coach Agent",
    layout="wide",
)

if "chat_history" not in st.session_state:
    st.session_state.chat_history = []

if "manual_debts" not in st.session_state:
    st.session_state.manual_debts = []

if "manual_spending" not in st.session_state:
    st.session_state.manual_spending = []

# with st.sidebar:
#     st.markdown("### 🎨 Appearance")
#     dark_mode = st.toggle("Dark Mode", value=True)

# def apply_dark_mode(enable: bool):
#     dark = """
#     <style>
#     .st-emotion-cache-13k62yr { background:#111 !important; color:#eee !important; }
#     textarea, input { background:#222 !important; color:#fff !important; }
#     </style>
#     """
#     light = """
#     <style>
#     .stApst-emotion-cache-13k62yrp { background:#fff !important; color:#000 !important; }
#     textarea, input { background:#f0f0f0 !important; color:#000 !important; }
#     </style>
#     """
#     return dark if enable else light

# apply_dark_mode(dark_mode)

# --------------------------------------------------
# Header
# --------------------------------------------------
st.title("💼 AI Financial Coach")
st.caption(
    "A personalized multi-agent financial advisor for debt, budgeting, savings, and FIRE planning."
)

st.divider()

# --------------------------------------------------
# Global User Profile (Top Section)
# --------------------------------------------------
st.subheader("👤 User Financial Profile")

CURRENCY_OPTIONS = {
    "USD ($)": {"symbol": "$", "code": "USD"},
    "EUR (€)": {"symbol": "€", "code": "EUR"},
    "GBP (£)": {"symbol": "£", "code": "GBP"},
    "INR (₹)": {"symbol": "₹", "code": "INR"},
    "AUD (A$)": {"symbol": "A$", "code": "AUD"},
    "CAD (C$)": {"symbol": "C$", "code": "CAD"},
}

currency_symbol = CURRENCY_OPTIONS["USD ($)"]["symbol"]
currency_code = CURRENCY_OPTIONS["USD ($)"]["code"]

col1, col2, col3, col4 = st.columns(4)

with col1:
    income = st.number_input(
        f"Monthly Net Income ({currency_symbol})",
        min_value=0.0,
        value=5000.0,
        step=100.0,
    )

with col2:
    savings = st.number_input(
        f"Current Total Savings ({currency_symbol})",
        min_value=0.0,
        value=10000.0,
        step=500.0,
    )

with col3:
    annual_spend = st.number_input(
        f"Annual Spending ({currency_symbol})",
        min_value=100.0,
        max_value=10_000_000.0,
        value=42000.0,
        step=1000.0,
    )

with col4:
    currency_choice = st.selectbox(
        "Preferred Currency",
        options=list(CURRENCY_OPTIONS.keys()),
        index=0,
    )

currency_symbol = CURRENCY_OPTIONS[currency_choice]["symbol"]
currency_code = CURRENCY_OPTIONS[currency_choice]["code"]

st.divider()

report_sections.append(f"- Monthly Income: {currency_symbol}{income:,.0f}")
report_sections.append(f"- Annual Spend: {currency_symbol}{annual_spend:,.0f}")
report_sections.append(f"- Current Savings: {currency_symbol}{savings:,.0f}\n")

# --------------------------------------------------
# KPI CARDS
# --------------------------------------------------
monthly_spend = annual_spend / 12
savings_rate = max(0.0, (income - monthly_spend) / income * 100)

fire_number_today = annual_spend * 25

kpi1, kpi2, kpi3, kpi4, kpi5, kpi6 = st.columns(6)

kpi1.metric(
    label="💵 Monthly Income",
    value=f"{currency_symbol}{income:,.0f}",
)

kpi2.metric(
    label="💰 Savings Rate",
    value=f"{savings_rate:.1f}%",
)

kpi3.metric(
    label="📆 Annual Spend",
    value=f"{currency_symbol}{annual_spend:,.0f}",
)

runway_years = savings / annual_spend if annual_spend > 0 else 0
kpi4.metric(
    label="⏳ Savings Runway",
    value=f"{runway_years:.1f} yrs",
)

kpi5.metric("🔥 FIRE Number (Today)", f"{currency_symbol}{fire_number_today:,.0f}")

runway_months = (
    savings / monthly_spend
    if monthly_spend > 0 else 0
)
kpi6.metric(
    "🛟 Emergency Fund Runway",
    f"{runway_months:.1f} months"
)
# --------------------------------------------------
# Tabs for Financial Tools
# --------------------------------------------------
tab_debt, tab_budget, tab_savings, tab_fire = st.tabs(
    ["💳 Debt Analysis", "📊 Budget Advisor", "💰 Savings Strategy", "🔥 FIRE Planning"]
)

# ==================================================
# 💳 DEBT ANALYSIS TAB
# ==================================================

df = pd.DataFrame()
with tab_debt:
    st.subheader("💳 Debt Analyzer")

    uploaded = st.file_uploader(
        "Upload Debt CSV",
        type=["csv"],
        help="Required columns: id, creditor, balance, rate, min_payment",
    )

    st.markdown("### ✍️ Enter Debts Manually")

    with st.form("add_debt_form", clear_on_submit=True):
        id = st.text_input("Debt ID")
        creditor = st.text_input("Creditor")
        balance = st.number_input("Balance", min_value=0.0)
        rate = st.number_input("Interest Rate (%)") / 100
        min_payment = st.number_input("Minimum Payment", min_value=0.0)
        type = st.text_input("Type (e.g., credit card, student loan)")

        submitted = st.form_submit_button("➕ Add Debt")

        if submitted:
            st.session_state.manual_debts.append({
                "id": id,
                "creditor": creditor,
                "balance": balance,
                "rate": rate,
                "min_payment": min_payment,
                "type": type
            })

    st.markdown("### 📋 Manual Debts")

    if st.session_state.manual_debts:
        for i, row in enumerate(st.session_state.manual_debts):
            c0, c1, c2, c3, c4, c5, c6 = st.columns([1, 3, 2, 2, 2, 1, 1])
            
            c0.text_input(
                "Id",
                value=row["id"],
                key=f"debt_id_{i}",
                on_change=lambda idx=i: st.session_state.manual_debts.__setitem__(
                    idx,
                    {**st.session_state.manual_debts[idx],
                    "id": st.session_state[f"debt_id_{idx}"]},
                ),
            )

            c1.text_input(
                "Creditor",
                value=row["creditor"],
                key=f"debt_creditor_{i}",
                on_change=lambda idx=i: st.session_state.manual_debts.__setitem__(
                    idx,
                    {**st.session_state.manual_debts[idx],
                    "creditor": st.session_state[f"debt_creditor_{idx}"]},
                ),
            )

            c2.number_input(
                "Balance",
                value=row["balance"],
                key=f"debt_balance_{i}",
                on_change=lambda idx=i: st.session_state.manual_debts.__setitem__(
                    idx,
                    {**st.session_state.manual_debts[idx],
                    "balance": st.session_state[f"debt_balance_{idx}"]},
                ),
            )

            c3.number_input(
                "Rate",
                value=row["rate"],
                format="%.4f",
                key=f"debt_rate_{i}",
                on_change=lambda idx=i: st.session_state.manual_debts.__setitem__(
                    idx,
                    {**st.session_state.manual_debts[idx],
                    "rate": st.session_state[f"debt_rate_{idx}"]},
                ),
            )

            c4.number_input(
                "Min Payment",
                value=row["min_payment"],
                key=f"debt_minpay_{i}",
                on_change=lambda idx=i: st.session_state.manual_debts.__setitem__(
                    idx,
                    {**st.session_state.manual_debts[idx],
                    "min_payment": st.session_state[f"debt_minpay_{idx}"]},
                ),
            )

            c6.text_input(
                "Type",
                value=row["type"],
                key=f"debt_type_{i}",
                on_change=lambda idx=i: st.session_state.manual_debts.__setitem__(
                    idx,
                    {**st.session_state.manual_debts[idx],
                    "type": st.session_state[f"debt_type_{idx}"]},
                ),
            )

            if c5.button("❌", key=f"debt_delete_{i}"):
                st.session_state.manual_debts.pop(i)
                st.experimental_rerun()
    else:
        st.info("No manual debts added yet.")

    # 1️⃣ Manual first
    if st.session_state.manual_debts:
        df = pd.DataFrame(st.session_state.manual_debts)

    # 2️⃣ Merge CSV if uploaded
    if uploaded:
        raw_bytes = uploaded.getvalue()
        decoded = raw_bytes.decode("utf-8-sig")
        csv_df = pd.read_csv(io.StringIO(decoded))
        csv_df = csv_df.loc[:, ~csv_df.columns.str.match("^Unnamed")]

        if not csv_df.empty:
            df = pd.concat([csv_df, df], ignore_index=True)

    # 3️⃣ Validate
    if df.empty:
        st.warning("Please upload a debt CSV with columns: `id`, `creditor`, `balance`, `rate`, `min_payment` or add debts manually.")
    else:
        df = df.loc[:, ~df.columns.str.match('^Unnamed')]
        df.index = df.index + 1

        total_debt = df["balance"].sum()

        weighted_rate = (
            (df["balance"] * df["rate"]).sum() / total_debt
            if total_debt > 0 else 0
        )

        annual_interest_cost = (df["balance"] * df["rate"]).sum()
        
        # --------------------------------------------------
        # Debt Overview Chart
        # --------------------------------------------------
        st.markdown("### 💳 Debt Balances by Creditor")

        fig, ax = plt.subplots()
        ax.barh(df["creditor"], df["balance"])
        ax.set_xlabel(f"Balance ({currency_symbol})")
        ax.set_title("Outstanding Debts")

        st.pyplot(fig, use_container_width=True)

        st.markdown("**Preview of uploaded data:**")
        st.dataframe(df.head(), use_container_width=True)

        if st.button("🚀 Run Debt Analysis"):
            with st.spinner("Analyzing your debt details..."):
                result = analyze_debt(df, income - df["min_payment"].sum(),currency_code, currency_symbol)

            st.subheader("📌 Optimized Debt Payoff Plan")
            d1, d2, d3 = st.columns(3)
            d1.metric("💳 Total Debt", f"{currency_symbol}{total_debt:,.0f}")
            d2.metric("📉 Avg Interest Rate", f"{weighted_rate*100:.2f}%")
            d3.metric("⏱️ Annual Interest Drag", f"{currency_symbol}{annual_interest_cost:,.0f}")
            st.markdown(result)
            report_sections.append("## Debt Analysis\n")
            report_sections.append(result + "\n")

# ==================================================
# 📊 BUDGET ADVISOR TAB
# ==================================================
spending_df = pd.DataFrame()
with tab_budget:
    st.subheader("📊 Actionable Budget Advisor")

    budget_file = st.file_uploader(
        "Upload Monthly Spending CSV",
        type=["csv"],
        key="budget_csv",
        help="Required columns: category, amount",
    )

    st.markdown("### ✍️ Enter Spending Manually")

    with st.form("add_spending_form", clear_on_submit=True):
        category = st.text_input("Category")
        amount = st.number_input("Amount", min_value=0.0)

        submitted = st.form_submit_button("➕ Add Category")

        if submitted:
            st.session_state.manual_spending.append({
                "category": category,
                "amount": amount,
            })
    
    st.markdown("### 📋 Manual Spending")

    if st.session_state.manual_spending:
        for i, row in enumerate(st.session_state.manual_spending):
            c1, c2, c3 = st.columns([3, 2, 1])

            c1.text_input(
                "Category",
                value=row["category"],
                key=f"sp_cat_{i}",
                on_change=lambda idx=i: st.session_state.manual_spending.__setitem__(
                    idx,
                    {**st.session_state.manual_spending[idx],
                    "category": st.session_state[f"sp_cat_{idx}"]},
                ),
            )

            c2.number_input(
                "Amount",
                value=row["amount"],
                key=f"sp_amt_{i}",
                on_change=lambda idx=i: st.session_state.manual_spending.__setitem__(
                    idx,
                    {**st.session_state.manual_spending[idx],
                    "amount": st.session_state[f"sp_amt_{idx}"]},
                ),
            )

            if c3.button("❌", key=f"sp_delete_{i}"):
                st.session_state.manual_spending.pop(i)
                st.experimental_rerun()
    else:
        st.info("No manual spending added yet.")

    # 1️⃣ Manual first
    if st.session_state.manual_spending:
        spending_df = pd.DataFrame(st.session_state.manual_spending)

    # 2️⃣ Merge CSV if uploaded
    if budget_file:
        raw = budget_file.getvalue().decode("utf-8-sig")
        csv_df = pd.read_csv(io.StringIO(raw))
        csv_df = csv_df.loc[:, ~csv_df.columns.str.match("^Unnamed")]

        if not csv_df.empty:
            spending_df = pd.concat([csv_df, spending_df], ignore_index=True)

    # 3️⃣ Validate
    if spending_df.empty:
        st.warning("Please upload a spending CSV with columns: `category`, `amount` or add categories manually.")
    else:
        st.markdown("### 📊 Spending Breakdown")

        fig, ax = plt.subplots()
        ax.pie(
            spending_df["amount"],
            labels=spending_df["category"],
            autopct="%1.0f%%",
            startangle=90,
        )
        ax.axis("equal")

        st.pyplot(fig, use_container_width=True)

        st.markdown("**Monthly Spending Preview:**")
        st.dataframe(spending_df, use_container_width=True)

        if st.button("📈 Generate Budget Advice"):
            with st.spinner("Analyzing your spending habits..."):
                budget_message = generate_budget_advice(
                    spending_df=spending_df,
                    income=income,
                    currency_code=currency_code, currency_symbol=currency_symbol
                )

            st.subheader("📌 Your Budget Recommendations")
            st.markdown(budget_message)
            report_sections.append("## Budget Advice\n")
            report_sections.append(budget_message + "\n")

# ==================================================
# 💰 SAVINGS STRATEGY TAB
# ==================================================
with tab_savings:
    SAVINGS_GOALS = {
        "Emergency Fund": "Build 3–6 months of essential expenses for safety.",
        "Home Down Payment": "Save for a future home purchase.",
        "Retirement (Traditional)": "Long-term retirement planning.",
        "Early Retirement": "Accelerated retirement through high savings.",
        "Education": "Save for education expenses.",
        "Wealth Building": "Maximize long-term net worth growth.",
    }

    st.subheader("💰 Custom Savings Strategy")

    savings_goal = st.selectbox(
        "Primary Savings Goal",
        options=list(SAVINGS_GOALS.keys()),
    )

    target_amount = st.number_input(
        f"Target Amount ({currency_symbol})",
        min_value=0.0,
        value=50000.0,
        step=1000.0,
    )

    if st.button("💡 Generate Savings Strategy"):
        with st.spinner("Creating your personalized savings strategy..."):
            savings_message = generate_savings_strategy(
                income=income,
                spend=annual_spend / 12,
                savings=savings,
                goal=SAVINGS_GOALS[savings_goal],
                target_amount=target_amount,
                currency_code=currency_code, 
                currency_symbol=currency_symbol
            )

        st.subheader("📌 Your Savings Plan")
        st.markdown(savings_message)
        report_sections.append("## Savings Strategy\n")
        report_sections.append(savings_message + "\n")
# ==================================================
# 🔥 FIRE PLANNING TAB
# ==================================================
with tab_fire:
    st.subheader("🔥 FIRE (Financial Independence, Retire Early) Planner")

    col1, col2, col3, col4 = st.columns(4)

    with col1:
        current_age = st.number_input(
            "Current Age",
            min_value=18,
            max_value=80,
            value=30,
        )

    with col2:
        retirement_age = st.number_input(
            "Target Retirement Age",
            min_value=current_age + 1,
            max_value=90,
            value=50,
        )

    with col3:
        inflation = st.number_input(
            "Expected Inflation Rate (%)",
            value=3.0,
        )

    with col4:
        annual_return = st.number_input(
            "Expected Annual Return (%)",
            value=7.0,
        )

    return_adjust = st.slider(
        "Adjust Expected Return (%)",
        -3.0, 3.0, 0.0
    )

    inflation_adjust = st.slider(
        "Adjust Inflation (%)",
        -2.0, 2.0, 0.0
    )

    adjusted_real_return = (
        (1 + (annual_return + return_adjust) / 100)
        / (1 + (inflation + inflation_adjust) / 100)
        - 1
    )

    real_return = (
        (1 + annual_return / 100) / (1 + inflation / 100) - 1
    )
    
    if st.button("🔥 Generate FIRE Plan"):
        with st.spinner("Analyzing your path to Financial Independence..."):
            fire_message = generate_fire_message(
                current_age=current_age,
                retirement_age=retirement_age,
                salary=income * 12,
                annual_spend=annual_spend,
                savings=savings,
                inflation=inflation,
                annual_return=annual_return,
                currency_code=currency_code, 
                currency_symbol=currency_symbol,
            )
        years_to_retirement = retirement_age - current_age
        annual_savings = max(0, (income * 12) - annual_spend)

        fire_probability = monte_carlo_fire_probability(
            initial_savings=savings,
            annual_savings=annual_savings,
            years=years_to_retirement,
            mean_return=real_return,
            fire_target=fire_number_today,
        )
        st.subheader("📌 Your FIRE Plan")
        fcl1, fcl2, fcl3 = st.columns(3)
        fcl1.metric(
            "📈 Real Annual Return",
            f"{real_return*100:.2f}%"
        )
        fcl2.metric(
            "Adjusted Real Return",
            f"{adjusted_real_return*100:.2f}%"
        )
        fcl3.metric(
            "🎯 Probability of Reaching FIRE",
            f"{fire_probability*100:.0f}%"
        )
        st.markdown(fire_message)
        report_sections.append("## FIRE Plan\n")
        report_sections.append(fire_message + "\n")

if len(report_sections) == 0:
    st.button(
        "⬇️ Download Financial Report",
        disabled=True,
        help="Run at least one analysis to enable download",
    )
else:
    full_report = "\n".join(report_sections)

    st.download_button(
        label="⬇️ Download Financial Report",
        data=full_report,
        file_name="ai_financial_coach_report.txt",
        mime="text/plain",
    )

st.divider()
# --------------------------------------------------
# 💬 Chat Interface (UX Fixed)
# --------------------------------------------------
st.subheader("💬 Ask Your AI Financial Coach")

# Render previous messages
for msg in st.session_state.chat_history:
    with st.chat_message(msg["role"]):
        st.markdown(msg["content"])
        if msg.get("resources"):
            with st.expander("📚 Sources used"):
                for r in msg["resources"]:
                    st.markdown(f"- {r}")

user_input = st.chat_input("Ask about debt, budget, savings, or FIRE…")

if user_input:
    # 1️⃣ Save and immediately show user message
    st.session_state.chat_history.append(
        {"role": "user", "content": user_input}
    )

    with st.chat_message("user"):
        st.markdown(user_input)

    # 2️⃣ Show assistant placeholder with spinner
    with st.chat_message("assistant"):
        with st.spinner("Thinking through your finances..."):
            try:
                from core.graph.financial_graph import graph

                result = graph.invoke({"user_input": user_input})
                agent_name = result["agent"]

                if agent_name == "debt_analysis":
                    response = debt_agent_wrapper(
                        df, income - df["min_payment"].sum(), currency_code, currency_symbol
                    )

                elif agent_name == "budget_analysis":
                    response = budget_agent_wrapper(
                        spending_df, income, currency_code, currency_symbol
                    )

                elif agent_name == "savings_strategy":
                    response = savings_agent_wrapper(
                        income,
                        annual_spend / 12,
                        savings,
                        SAVINGS_GOALS[savings_goal],
                        target_amount,
                        currency_code,
                        currency_symbol,
                    )

                elif agent_name == "fire_planning":
                    response = fire_agent_wrapper(
                        current_age,
                        retirement_age,
                        income,
                        savings,
                        inflation,
                        annual_return,
                        annual_spend,
                        currency_code,
                        currency_symbol,
                    )

                else:
                    response = AgentResponse(
                        message="I couldn’t determine the correct analysis.",
                        resources=[],
                    )

            except Exception as e:
                response = AgentResponse(
                    message=f"Something went wrong: {e}",
                    resources=[],
                )

    # 3️⃣ Persist assistant response
    st.session_state.chat_history.append(
        {
            "role": "assistant",
            "content": response.message,
            "resources": response.resources,
        }
    )

    # 4️⃣ Render assistant response cleanly
    with st.chat_message("assistant"):
        st.markdown(response.message)

