# core/__init__.py

from .config import (
    OPENROUTER_API_KEY,
    OPENROUTER_BASE_URL,
    CHROMA_DB_DIR,
)

from .llm_client import get_chat_model
