# core/rag/vector_store.py

from typing import List, Dict
import pandas as pd
import chromadb
from chromadb.config import Settings
from sentence_transformers import SentenceTransformer

DEFAULT_MODEL = "all-MiniLM-L6-v2"


class TabularRAG:
    def __init__(
        self,
        persist_directory: str,
        collection_name: str = "user_finances",
        model_name: str = DEFAULT_MODEL,
    ):
        self.persist_directory = persist_directory
        self.collection_name = collection_name
        self.embedder = SentenceTransformer(model_name)

        self.client = chromadb.Client(
            Settings(
                persist_directory=persist_directory,
                anonymized_telemetry=False,
            )
        )

        self.collection = self.client.get_or_create_collection(
            name=collection_name
        )

    def _row_to_text(self, row: Dict) -> str:
        return " | ".join(f"{k}: {v}" for k, v in row.items())

    def build_from_df(self, df: pd.DataFrame):
        texts = []
        metadatas = []
        ids = []

        for idx, row in df.iterrows():
            texts.append(self._row_to_text(row.to_dict()))
            metadatas.append(row.to_dict())
            ids.append(str(idx))

        embeddings = self.embedder.encode(
            texts,
            show_progress_bar=False,
            normalize_embeddings=True,
        ).tolist()

        self.collection.upsert(
            documents=texts,
            metadatas=metadatas,
            ids=ids,
            embeddings=embeddings,
        )

        self.client.persist()

    def query(self, query_text: str, n_results: int = 5) -> Dict:
        query_embedding = self.embedder.encode(
            query_text,
            normalize_embeddings=True,
        ).tolist()

        return self.collection.query(
            query_embeddings=[query_embedding],
            n_results=n_results,
        )
