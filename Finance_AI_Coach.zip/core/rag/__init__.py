# core/rag/__init__.py

from .vector_store import TabularRAG

__all__ = ["TabularRAG"]
