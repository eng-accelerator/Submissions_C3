# core/utils/inflation.py
import httpx
from typing import Optional

WB_INDICATOR = "FP.CPI.TOTL.ZG"  # inflation, consumer prices (annual %)

def fetch_country_inflation(country_iso2: str) -> Optional[float]:
    """
    Fetch latest annual consumer price inflation (%) for a country using World Bank API.
    country_iso2: 2-letter ISO code (e.g., 'IN' for India, 'US' for United States)
    Returns latest available annual inflation % (float) or None.
    """
    url = f"https://api.worldbank.org/v2/country/{country_iso2}/indicator/{WB_INDICATOR}?format=json&per_page=5"
    try:
        return float(4.0)
        # resp = httpx.get(url, timeout=10.0)
        # data = resp.json()
        # # API returns [metadata, [records...]]
        # if not data or len(data) < 2:
        #     return None
        # records = data[1]
        # # find first non-null value (most recent)
        # for rec in records:
        #     val = rec.get("value")
        #     if val is not None:
        #         return float(val)
    except Exception:
        return None
    return None
