# core/utils/finance_math.py
from typing import List, Dict
import math
import numpy as np

def compute_fire_target(annual_spend: float, multiplier: int = 25) -> float:
    """
    Basic FIRE target = annual_spend * multiplier (e.g. 25 for 4% rule).
    """
    return annual_spend * multiplier

def amortization_schedule(principal: float, annual_rate: float, years: int) -> List[Dict]:
    """
    Returns amortization schedule (simple fixed-payment).
    """
    r = annual_rate / 12.0
    n = years * 12
    if r == 0:
        payment = principal / n
    else:
        payment = (principal * r) / (1 - (1 + r) ** -n)
    schedule = []
    bal = principal
    for i in range(1, n+1):
        interest = bal * r
        principal_paid = payment - interest
        bal -= principal_paid
        schedule.append({"month": i, "payment": payment, "interest": interest, "principal_paid": principal_paid, "balance": max(0.0, bal)})
    return schedule

def monte_carlo_fire_probability(
    initial_savings: float,
    annual_savings: float,
    years: int,
    mean_return: float,
    volatility: float = 0.12,
    fire_target: float = 1_000_000,
    simulations: int = 1000,
) -> float:
    successes = 0

    for _ in range(simulations):
        portfolio = initial_savings
        for _ in range(years):
            r = np.random.normal(mean_return, volatility)
            portfolio = portfolio * (1 + r) + annual_savings

        if portfolio >= fire_target:
            successes += 1

    return successes / simulations