from dataclasses import dataclass
from typing import List

@dataclass
class AgentResponse:
    message: str
    resources: List[str]
