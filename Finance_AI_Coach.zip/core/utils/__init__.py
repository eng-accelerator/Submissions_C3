# core/utils/__init__.py

from .inflation import fetch_country_inflation
from .finance_math import (
    compute_fire_target,
    amortization_schedule,
    monte_carlo_fire_probability
)

__all__ = [
    "fetch_country_inflation",
    "compute_fire_target",
    "monte_carlo_fire_probability",
    "amortization_schedule",
]
