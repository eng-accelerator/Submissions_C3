# core/llm_client.py
from typing import Optional, Dict, Any
from core.config import OPENROUTER_API_KEY, OPENROUTER_BASE_URL
from langchain_openai import ChatOpenAI  # LangChain's openai-compatible wrapper
from langchain.chat_models.base import BaseChatModel

def get_chat_model(model: str = "openai/gpt-4o-mini", temperature: float = 0.2) -> BaseChatModel:
    """
    Returns a configured LangChain chat model that points at OpenRouter.
    Provide OPENROUTER_API_KEY in env. Model names should match models available via OpenRouter.
    """
    if not OPENROUTER_API_KEY:
        raise RuntimeError("OPENROUTER_API_KEY not set. Add to .env")
    # ChatOpenAI uses openai_api_base/openai_api_key style args for alternative endpoints.
    model_client = ChatOpenAI(
        model=model,
        temperature=temperature,
        openai_api_key=OPENROUTER_API_KEY,
        openai_api_base=OPENROUTER_BASE_URL,
    )
    return model_client