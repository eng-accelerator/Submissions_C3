from langgraph.graph import StateGraph
from typing import TypedDict

class AgentState(TypedDict):
    user_input: str
    agent: str

def router_node(state):
    from agents.router import route_agent
    return {"agent": route_agent(state["user_input"])}

graph = StateGraph(AgentState)
graph.add_node("router", router_node)
graph.set_entry_point("router")
graph = graph.compile()