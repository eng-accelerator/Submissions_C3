# agents/__init__.py

from .debt_analyzer import analyze_debt
from .savings_agent import generate_savings_strategy
from .budget_agent import generate_budget_advice
from .fire_planner import plan_fire, generate_fire_message
from .router import route_agent

__all__ = [
    "analyze_debt",
    "generate_savings_strategy",
    "generate_budget_advice",
    "plan_fire",
    "generate_fire_message",
    "route_agent"
]
