# agents/budget_agent.py

from core.llm_client import get_chat_model
import pandas as pd

BUDGET_PROMPT = """
All monetary values are in {currency_code} ({currency_symbol}).
You are a budgeting expert.

User monthly spending breakdown:
{spending}

Monthly income: {income}

Create an ACTIONABLE budget:
1. What to cut or cap
2. Target amounts per category
3. Savings increase opportunities
4. 30-60-90 day action plan

Explain clearly to the user and also provide the users what parameters you have used to calculate the budget advice.
Do NOT return JSON.
"""

def generate_budget_advice(
    spending_df: pd.DataFrame,
    income: float,
    currency_code: str,
    currency_symbol: str,
    model_name: str = "openai/gpt-4o-mini",
) -> str:
    llm = get_chat_model(model=model_name, temperature=0.3)

    spending_text = "\n".join(
        f"{row.category}: {row.amount}"
        for row in spending_df.itertuples()
    )

    prompt = BUDGET_PROMPT.format(
        spending=spending_text,
        income=income,
        currency_code=currency_code,
        currency_symbol=currency_symbol,
    )

    response = llm.invoke(prompt)
    return response.content
