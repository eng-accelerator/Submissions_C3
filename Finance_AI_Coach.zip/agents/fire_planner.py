# agents/fire_planner.py
from core.utils.inflation import fetch_country_inflation
from core.utils.finance_math import compute_fire_target
from core.llm_client import get_chat_model
from langchain.chains import LLMChain
from langchain.prompts import ChatPromptTemplate
from langchain.prompts.chat import (
    SystemMessagePromptTemplate,
    HumanMessagePromptTemplate,
)

FIRE_PROMPT = """
All monetary values are in {currency_code} ({currency_symbol}).
You are a retirement planning expert. The user has:
- current_age: {age}
- annual_spend_today: {annual_spend}
- country_iso2: {country}
- expected future plans: {plans}
- current_savings: {savings}
- projected annual return assumption: {return_pct}

Latest country inflation (annual %): {inflation}

Calculate:
1) FIRE target today (25x rule) and inflation-adjusted FIRE target in N years.
2) Suggested annual savings rate and instruments to reach FIRE within target years.

Return response should have the parameters you have used to calculate the FIRE plan, along with a clear step-by-step plan for the user to follow.
Do NOT return JSON.

"""

def plan_fire(age: int, 
              annual_spend: float, 
              country_iso2: str, 
              plans: str, 
              savings: float, 
              currency_code: str,
              currency_symbol: str,
              return_pct: float = 0.05, 
              target_years: int = 20, 
              model_name: str="openai/gpt-4o-mini"):
    inflation = fetch_country_inflation(country_iso2) or 2.5
    fire_now = compute_fire_target(annual_spend, multiplier=25)
    # inflation-adjusted target in target_years (approx): fire_now * (1+inflation/100)^target_years
    adj_fire = fire_now * ((1 + (inflation/100)) ** target_years)
    # prompt to LLM for coherent plan
    chat = get_chat_model(model=model_name, temperature=0.2)
    prompt = FIRE_PROMPT.format(age=age, 
                                annual_spend=annual_spend, country=country_iso2, plans=plans, savings=savings, return_pct=return_pct, 
                                inflation=inflation, 
                                currency_code=currency_code,
                                currency_symbol=currency_symbol)
    chain = LLMChain(llm=chat, prompt=ChatPromptTemplate.from_messages([
        SystemMessagePromptTemplate.from_template("You are a retirement planning expert."),
        HumanMessagePromptTemplate.from_template("{input}")
    ]))
    resp = chain.run({"input": prompt})
    import json
    try:
        parsed = json.loads(resp)
    except:
        parsed = {"raw": resp}
    parsed.update({"fire_now": fire_now, "inflation_pct": inflation, "inflation_adjusted_fire_in_yrs": adj_fire})
    return parsed

FIRE_MESSAGE_PROMPT = """
You are a Financial Independence (FIRE) coach.

User details:
- Current age: {current_age}
- Target retirement age: {retirement_age}
- Current annual salary: {salary}
- Current annual spending: {annual_spend}
- Current savings: {savings}
- Expected inflation rate (%): {inflation}
- Expected annual return (%): {annual_return}

Explain in a friendly, conversational way:
1. Their estimated FIRE number (today’s dollars)
2. Inflation-adjusted FIRE target at retirement
3. Years remaining until retirement
4. Whether their goal looks realistic
5. Clear next steps they should take

Do NOT return JSON.
Write directly to the user.
"""

def generate_fire_message(
    current_age: int,
    retirement_age: int,
    salary: float,
    annual_spend: float,
    savings: float,
    inflation: float,
    annual_return: float,
    currency_code: str,
    currency_symbol: str,
    model_name: str = "openai/gpt-4o-mini",
) -> str:
    llm = get_chat_model(model=model_name, temperature=0.3)

    prompt = FIRE_MESSAGE_PROMPT.format(
        current_age=current_age,
        retirement_age=retirement_age,
        salary=salary,
        annual_spend=annual_spend,
        savings=savings,
        inflation=inflation,
        annual_return=annual_return,
        currency_code=currency_code,
        currency_symbol=currency_symbol,
    )

    response = llm.invoke(prompt)
    return response.content