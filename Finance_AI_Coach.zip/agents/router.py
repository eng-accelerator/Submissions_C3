from core.llm_client import get_chat_model
from langchain_openai import ChatOpenAI
from langchain.prompts import ChatPromptTemplate

ROUTER_PROMPT = ChatPromptTemplate.from_messages([
    (
        "system",
        """
You are a financial assistant router.

Given a user message, decide which tool should be used.

Available tools:
- debt_analysis
- budget_analysis
- savings_strategy
- fire_planning

Return ONLY the tool name.
"""
    ),
    ("human", "{user_input}")
])

def route_agent(user_input: str, model_name: str = "openai/gpt-4o-mini") -> str:
    llm = get_chat_model(model=model_name, temperature=0.3)
    chain = ROUTER_PROMPT | llm
    response = chain.invoke({"user_input": user_input})
    return response.content.strip()