# agents/savings_agent.py
from core.llm_client import get_chat_model
from langchain.chains import LLMChain
from langchain.prompts import ChatPromptTemplate
from langchain.prompts.chat import (
    SystemMessagePromptTemplate,
    HumanMessagePromptTemplate,
)

SAVINGS_PROMPT = """
All monetary values are in {currency_code} ({currency_symbol}).
You are a personal finance coach.

User details:
- Monthly income: {income}
- Monthly spending: {spend}
- Current savings: {savings}
- Financial goal: {goal}
- Target savings for goal: {target_amount}

Create a CUSTOM savings strategy:
1. Emergency fund target and timeline
2. Monthly savings amount and % of income
3. Where to save/invest (cash, retirement, brokerage)
4. Milestones to track progress for the goal
5. Trade-offs and risks

Respond clearly to the user and also provide the parameters you have used to calculate the savings strategy.
Do NOT return JSON.
"""

def generate_savings_strategy(
    income: float,
    spend: float,
    savings: float,
    goal: str,
    target_amount: float,
    currency_code: str,
    currency_symbol: str,
    model_name: str = "openai/gpt-4o-mini"
) -> str:
    llm = get_chat_model(model=model_name, temperature=0.3)

    prompt = SAVINGS_PROMPT.format(
        income=income,
        spend=spend,
        savings=savings,
        goal=goal,
        target_amount=target_amount,
        currency_code=currency_code,
        currency_symbol=currency_symbol,
    )

    response = llm.invoke(prompt)
    return response.content

