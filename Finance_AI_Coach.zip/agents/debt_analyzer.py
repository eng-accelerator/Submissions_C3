# agents/debt_analyzer.py
from typing import List, Dict, Any
from core.llm_client import get_chat_model
from langchain.prompts import ChatPromptTemplate
from langchain.prompts.chat import (
    SystemMessagePromptTemplate,
    HumanMessagePromptTemplate,
)
from langchain.chains import LLMChain
import pandas as pd
from core.utils.finance_math import amortization_schedule

DEBT_PROMPT = """
All monetary values are in {currency_code} ({currency_symbol}).
You are a professional financial advisor specializing in debt optimization.

Below is a user's list of debts. Each debt includes:
- Creditor
- Balance
- Interest rate
- Minimum monthly payment

Debts:
{debts}

The user has {available_monthly} available per month to allocate toward debt payments.

Your task:
1. Recommend an optimized debt payoff strategy (avalanche, snowball, or hybrid).
2. Clearly list the recommended payoff order.
3. Suggest how the extra monthly amount should be allocated.
4. Estimate how this strategy improves interest savings or payoff time.
5. Give clear next steps the user should follow.

Write directly to the user in clear, friendly language.
Also add the parameters you have used to calculate the debt payoff strategy.
Do NOT return JSON.
"""

def summarize_debts_as_text(df: pd.DataFrame) -> str:
    rows = []
    for _, r in df.iterrows():
        rows.append(f"id:{r['id']}, creditor:{r.get('creditor','')}, balance:{r['balance']}, rate:{r['rate']}, min_payment:{r['min_payment']}")
    return "\n".join(rows)

def analyze_debt(df: pd.DataFrame, 
                 available_monthly: float, 
                 currency_code: str,
                 currency_symbol: str,
                 model_name: str = "openai/gpt-4o-mini") -> Dict[str, Any]:
    chat = get_chat_model(model=model_name, temperature=0.0)
    debts_text = summarize_debts_as_text(df)
    prompt = DEBT_PROMPT.format(debts=debts_text, 
                                available_monthly=available_monthly, 
                                currency_code=currency_code,
                                currency_symbol=currency_symbol,)
    chain = LLMChain(llm=chat, prompt=ChatPromptTemplate.from_messages([
        SystemMessagePromptTemplate.from_template("You help users with debt payoff strategies."),
        HumanMessagePromptTemplate.from_template("{input}")
    ]))
    return chain.run({"input": prompt})
