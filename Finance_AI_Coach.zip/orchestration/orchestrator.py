# orchestration/orchestrator.py
from typing import TypedDict
from langgraph.graph import StateGraph, END, START
from agents.debt_analyzer import analyze_debt
from agents.savings_agent import propose_savings_strategy

class FinanceState(TypedDict):
    debts: list
    income: float
    savings: float
    budget: dict
    results: dict

def run_workflow(state: FinanceState):
    # Build a small LangGraph that runs debt_analysis then savings strategy and collates results
    graph_builder = StateGraph(FinanceState)

    @graph_builder.add_node("debt_analysis")
    def debt_node(state, config, runtime):
        # convert state['debts'] to pandas DataFrame as expected by analyzer
        import pandas as pd
        df = pd.DataFrame(state['debts'])
        res = analyze_debt(df, available_monthly=state.get('income',0)-sum(state.get('budget',{}).values()))
        return {"results": {"debt_plan": res}}

    @graph_builder.add_node("savings_strategy")
    def savings_node(state, config, runtime):
        res = propose_savings_strategy(state.get('income',0), state.get('savings',0), monthly_spend=sum(state.get('budget',{}).values()), goals="Early retirement")
        return {"results": {"savings": res}}

    graph_builder.add_edge(START, "debt_analysis")
    graph_builder.add_edge("debt_analysis", "savings_strategy")
    graph_builder.add_edge("savings_strategy", END)

    graph = graph_builder.build()
    runtime = graph.run(state)
    return runtime
