from core.utils.agent_response import AgentResponse
from agents.debt_analyzer import analyze_debt

def debt_agent_wrapper(df, available_monthly, currency_code, currency_symbol):
    message = analyze_debt(df, available_monthly, currency_code=currency_code, currency_symbol=currency_symbol)
    resources = [
        "Debt balances provided by user",
        "Interest rate comparison",
        "Time value of money principle",
    ]
    return AgentResponse(message=message, resources=resources)