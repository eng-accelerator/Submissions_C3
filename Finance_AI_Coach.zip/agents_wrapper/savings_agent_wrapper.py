from core.utils.agent_response import AgentResponse
from agents.savings_agent import generate_savings_strategy

def savings_agent_wrapper(income, 
                         savings, goal, target_amount,
                         annual_spend, 
                         currency_code,
                         currency_symbol):
    message = generate_savings_strategy(
                income=income,
                spend=annual_spend / 12,
                savings=savings,
                goal=goal,
                target_amount=target_amount,
                currency_code=currency_code, 
                currency_symbol=currency_symbol
            )
    resources = [
        "Savings strategies and principles",
        "Savings goal setting",
        "Savings optimization techniques",
        "Savings tracking methods",
        "Savings risk management",
        "Savings investment options",
        "Savings milestones and timelines",
    ]
    return AgentResponse(message=message, resources=resources)