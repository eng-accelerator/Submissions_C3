from core.utils.agent_response import AgentResponse
from agents.fire_planner import generate_fire_message

def fire_agent_wrapper(current_age, retirement_age, income, 
                         savings, inflation, annual_return,
                         annual_spend, 
                         currency_code,
                         currency_symbol):
    message = generate_fire_message(
                current_age=current_age,
                retirement_age=retirement_age,
                salary=income * 12,
                annual_spend=annual_spend,
                savings=savings,
                inflation=inflation,
                annual_return=annual_return,
                currency_code=currency_code, 
                currency_symbol=currency_symbol,
            )
    resources = [
        "FIRE planning principles",
        "FIRE number calculation",
        "FIRE strategy and steps",
    ]
    return AgentResponse(message=message, resources=resources)