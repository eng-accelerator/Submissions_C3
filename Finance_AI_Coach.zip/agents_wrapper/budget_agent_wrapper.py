from core.utils.agent_response import AgentResponse
from agents.budget_agent import generate_budget_advice

def budget_agent_wrapper(df, income, currency_code, currency_symbol):
    message = generate_budget_advice(
                    spending_df=df,
                    income=income,
                    currency_code=currency_code, currency_symbol=currency_symbol
                )
    resources = [
        "Budget balances provided by user",
        "Budget categories analysis",
        "Budget planning, spending, optimization, and tracking techniques",
    ]
    return AgentResponse(message=message, resources=resources)