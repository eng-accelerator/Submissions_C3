This is multi AI agent Financial coach app

To run this application provide your Open router key in env file and after setting up the python env. run the following commands:

pip install -r requirements.txt
streamlit run streamlit_app.py