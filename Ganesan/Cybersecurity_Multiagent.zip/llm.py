#from langchain.chat_models import ChatOpenAI
from langchain_openai import ChatOpenAI


llm = ChatOpenAI(
    temperature=0,
    model="gpt-4o-mini",  # or openrouter model
    openai_api_key="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"
)
