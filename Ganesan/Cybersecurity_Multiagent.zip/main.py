from agents.log_monitor import LogMonitorAgent
from agents.threat_intel import ThreatIntelAgent
from agents.vuln_scanner import VulnerabilityScannerAgent
from agents.policy_checker import PolicyCheckerAgent
from agents.incident_response import IncidentResponseAgent

log_agent = LogMonitorAgent()
threat_agent = ThreatIntelAgent()
vuln_agent = VulnerabilityScannerAgentold()
policy_agent = PolicyCheckerAgent()
response_agent = IncidentResponseAgent()

print("🔍 Running Cyber Security AI Agent...\n")

logs = log_agent.analyze_logs("data/system.log")
threats = threat_agent.check_threats(logs, "data/cve_db.txt")
vulns = vuln_agent.scan_code(".")
policy_gaps = policy_agent.check_policies(
    config_text="password_policy enabled",
    policy_file="data/security_policies.txt"
)

findings = {
    "Log Alerts": logs,
    "Threat Matches": threats,
    "Code Vulnerabilities": vulns,
    "Policy Gaps": policy_gaps
}

response = response_agent.generate_response(findings)

print("🚨 INCIDENT RESPONSE PLAN\n")
print(response)
