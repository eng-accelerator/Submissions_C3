import streamlit as st
import os

from agents.log_monitor import LogMonitorAgent
from agents.threat_intel import ThreatIntelAgent
from agents.vuln_scanner import VulnerabilityScannerAgent
from agents.policy_checker import PolicyCheckerAgent
from agents.incident_response import IncidentResponseAgent

st.set_page_config(page_title="Cyber Security AI Agent", layout="wide")

st.title("🛡️ Cyber Security Multi-Agent System")

st.sidebar.header("📂 Upload Data Files")

# File uploads
log_file = st.sidebar.file_uploader("Upload system.log", type=["log", "txt"])
cve_file = st.sidebar.file_uploader("Upload cve_db.txt", type=["txt"])
policy_file = st.sidebar.file_uploader("Upload security_policies.txt", type=["txt"])

scan_path = st.sidebar.text_input("Code Scan Path", value="agents")

run_btn = st.sidebar.button("🚀 Run Security Analysis")

# Save uploaded files
def save_file(uploaded_file, path):
    with open(path, "wb") as f:
        f.write(uploaded_file.getbuffer())

if run_btn:
    if not (log_file and cve_file and policy_file):
        st.error("❌ Please upload all required files")
        st.stop()

    os.makedirs("ui_data", exist_ok=True)

    log_path = "ui_data/system.log"
    cve_path = "ui_data/cve_db.txt"
    policy_path = "ui_data/security_policies.txt"

    save_file(log_file, log_path)
    save_file(cve_file, cve_path)
    save_file(policy_file, policy_path)

    # Initialize agents
    log_agent = LogMonitorAgent()
    threat_agent = ThreatIntelAgent()
    vuln_agent = VulnerabilityScannerAgent()
    policy_agent = PolicyCheckerAgent()
    response_agent = IncidentResponseAgent()

    # Run agents
    logs = log_agent.analyze_logs(log_path)
    threats = threat_agent.check_threats(logs, cve_path)
    vulns = vuln_agent.scan_code(scan_path)
    policy_gaps = policy_agent.check_policies(
        config_text="password_policy enabled",
        policy_file=policy_path
    )

    findings = {
        "Log Alerts": logs,
        "Threat Matches": threats,
        "Code Vulnerabilities": vulns,
        "Policy Gaps": policy_gaps
    }

    response = response_agent.generate_response(findings)

    # UI OUTPUT
    st.success("✅ Analysis Completed")

    col1, col2 = st.columns(2)

    with col1:
        st.subheader("🚨 Log Alerts")
        st.write(logs or "No issues found")

        st.subheader("🦠 Threat Intelligence Matches")
        st.write(threats or "No known threats matched")

    with col2:
        st.subheader("🔍 Code Vulnerabilities")
        st.write(vulns or "No vulnerabilities found")

        st.subheader("📋 Policy Gaps")
        st.write(policy_gaps or "No policy gaps")

    st.subheader("🤖 AI Incident Response Plan")
    st.markdown(response)
