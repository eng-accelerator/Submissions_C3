class PolicyCheckerAgent:
    def check_policies(self, config_text, policy_file):
        gaps = []
        with open(policy_file) as f:
            policies = f.readlines()

        for policy in policies:
            if policy.strip() not in config_text:
                gaps.append(policy.strip())

        return gaps
