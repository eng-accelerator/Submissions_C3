from llm import llm

class IncidentResponseAgent:
    def generate_response(self, findings):
        prompt = f"""
        You are a cybersecurity incident response expert.
        Analyze the findings below and generate a step-by-step action plan.

        Findings:
        {findings}
        """
        return llm.invoke(prompt).content
       # return llm.predict(prompt)
       
