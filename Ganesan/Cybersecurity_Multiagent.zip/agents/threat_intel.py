class ThreatIntelAgent:
    def check_threats(self, indicators, cve_db):
        matches = []
        with open(cve_db, "r") as f:
            cves = f.read().lower()

        for item in indicators:
            if any(word in cves for word in item.lower().split()):
                matches.append(item)

        return matches
