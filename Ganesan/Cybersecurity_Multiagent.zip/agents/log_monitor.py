import re

class LogMonitorAgent:
    def analyze_logs(self, log_file):
        alerts = []
        with open(log_file, "r") as f:
            for line in f:
                if re.search(r"(failed login|unauthorized|error)", line, re.I):
                    alerts.append(line.strip())
        return alerts
