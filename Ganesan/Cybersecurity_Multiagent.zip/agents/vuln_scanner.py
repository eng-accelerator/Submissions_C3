import os

class VulnerabilityScannerAgent:
    def scan_code(self, path="."):
        issues = []

        for root, _, files in os.walk(path):
            for file in files:
                if file.endswith(".py"):
                    file_path = os.path.join(root, file)
                    try:
                        with open(file_path, "r", encoding="utf-8", errors="ignore") as f:
                            if "eval(" in f.read():
                                issues.append(f"Insecure eval usage in {file_path}")
                    except:
                        continue

        return issues
